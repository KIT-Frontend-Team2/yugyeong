const ContextQ2Form2 = () => {
  return (
    <div>
      <h1>Q2Form2</h1>
      <button>STATUS 추가</button>
    </div>
  );
};
export default ContextQ2Form2;
