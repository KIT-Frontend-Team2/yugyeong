const ContextQ2Form3 = () => {
  return (
    <div>
      <h1>Q2Form3</h1>
      <button>RESET</button>
    </div>
  );
};
export default ContextQ2Form3;
