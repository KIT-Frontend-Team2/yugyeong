const ContextQ1Modal = () => {
  return (
    <>
      <h1>ContextQ1Modal</h1>
    </>
  );
};
export default ContextQ1Modal;
